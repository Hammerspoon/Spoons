= Support scripts

Some scripts used by the policy to interact with the system. Most of
these scripts have not been written by me, although in some I have
made some small changes - each script contains references to its
original author/source.

