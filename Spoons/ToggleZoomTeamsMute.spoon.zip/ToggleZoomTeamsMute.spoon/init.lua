--- === ToggleZoomTeamsMute ===
---
--- Provide keybindings for muting/unmuting Zoom and Microsoft Teams
---

local obj={}
obj.__index = obj

-- Metadata
obj.name = "ToggleZoomTeamsMute"
obj.version = "0.1"
obj.author = "me <mseewald@gmail.com>"
obj.homepage = "https://github.com/Hammerspoon/Spoons"
obj.license = "MIT - https://opensource.org/licenses/MIT"

--- ToggleZoomTeamsMute.logger
--- Variable
--- Logger object used within the Spoon. Can be accessed to set the default log level for the messages coming from the Spoon.
obj.logger = hs.logger.new('ToggleZoomTeamsMute')

--- ToggleZoomTeamsMute:toggle(app)
--- Method
--- Toggle Zooom or Microsoft Teams between muted/unmuted, whether focused or not
---
--- Returns:
---  * None
function obj:toggle()
   local lastapp = nil

   local teams = hs.appfinder.appFromWindowTitlePattern("Meeting with.*")
   if teams then
      local teamswindow = hs.appfinder.windowFromWindowTitlePattern("Meeting with.*")
      teamswindow:becomeMain()
      if not teams:isFrontmost() then
         lastapp = hs.application.frontmostApplication()
         teams:activate()
      end
      hs.eventtap.keyStroke( {"shift", "cmd"}, "m")
   end

   local zoom = hs.appfinder.appFromWindowTitlePattern("Zoom Meeting.*")
   if zoom then
      if not zoom:isFrontmost() then
         lastapp = hs.application.frontmostApplication()
         zoom:activate()
      end
      hs.eventtap.keyStroke( {"shift", "cmd"}, "a")
   end

   if lastapp then
      lastapp:activate()
   end
end

--- ToggleZoomTeamsMute:bindHotkeys(mapping)
--- Method
--- Binds hotkeys for ToggleZoomTeamsMute
---
--- Parameters:
---  * mapping - A table containing hotkey modifier/key details for the following items:
---   * toggle_zoomteams - Mute/unmute active conversation in Teams
function obj:bindHotkeys(mapping)
   local def = {
      toggle_zoomteams = function() self:toggle() end
   }
   hs.spoons.bindHotkeysToSpec(def, mapping)
end

return obj
