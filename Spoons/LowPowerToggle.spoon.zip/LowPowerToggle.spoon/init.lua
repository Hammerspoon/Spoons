local obj = {}

obj.idleThreshold = 300 -- seconds (5 min)
obj.lowPowerEnabled = false
obj.timer = nil
obj.eventtap = nil

local function toggleLowPower(enable)
    if obj.lowPowerEnabled ~= enable then
        local cmd = enable and "pmset -a lowpowermode 1" or "pmset -a lowpowermode 0"
        hs.execute("sudo " .. cmd)
        obj.lowPowerEnabled = enable
        hs.alert.show("Low Power Mode " .. (enable and "Enabled" or "Disabled"))
    end
end

local function resetTimer()
    if obj.timer then
        obj.timer:stop()
    end
    toggleLowPower(false)
    obj.timer = hs.timer.doAfter(obj.idleThreshold, function()
        toggleLowPower(true)
    end)
end

function obj:start()
    if self.eventtap then return end
    self.eventtap = hs.eventtap.new({hs.eventtap.event.types.keyDown, hs.eventtap.event.types.mouseMoved}, function()
        resetTimer()
        return false
    end)
    self.eventtap:start()
    resetTimer()
end

function obj:stop()
    if self.eventtap then
        self.eventtap:stop()
        self.eventtap = nil
    end
    if self.timer then
        self.timer:stop()
        self.timer = nil
    end
    toggleLowPower(false)
end

return obj

