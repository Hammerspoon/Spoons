# LowPowerToggle Spoon for Hammerspoon

Automatically toggles macOS Low Power Mode based on user inactivity.

---

## Features

- Monitors keyboard and mouse idle activity in real-time.
- Enables Low Power Mode after a configurable idle timeout (default 5 minutes).
- Disables Low Power Mode immediately upon user activity.
- Shows macOS alerts on mode changes.

---

## Installation

1. Place the `LowPowerToggle.spoon` folder inside your `~/.hammerspoon/Spoons/` directory.

2. Add the following to your `~/.hammerspoon/init.lua`:

```lua
local lowPowerToggle = hs.loadSpoon("LowPowerToggle")
lowPowerToggle:start()
````

3. Reload your Hammerspoon config (via the menu or `hs.reload()`).

---

## Requirements

* macOS 12.3 or later (supports Low Power Mode).
* [Hammerspoon](https://www.hammerspoon.org) installed.

---

## Important: Spoon runs `pmset` commands using `sudo`

To toggle Low Power Mode, this Spoon runs these `pmset` commands **with `sudo` privileges**:

```bash
sudo pmset -a lowpowermode 0
sudo pmset -a lowpowermode 1
```

Because of this, you will be prompted for your password unless you configure passwordless sudo for these commands.

---

## Allow passwordless sudo for `pmset`

To avoid password prompts every time, add this line to your sudoers file (via `sudo visudo`):

```bash
yourusername ALL=(ALL) NOPASSWD: /usr/bin/pmset -a lowpowermode 0, /usr/bin/pmset -a lowpowermode 1
```

Replace `yourusername` with your macOS user account name.

---

### Quick setup script

You can use the included script `add_pmset_to_sudo.sh` to safely add this rule automatically:

```bash
sudo bash add_pmset_to_sudo.sh
```

---

## Configuration

* Idle timeout is set to 300 seconds (5 minutes) by default.
* To change, edit the `idleThreshold` variable in `init.lua` and **reload** Hammerspoon.