#!/bin/bash

USER=$(whoami)
RULE="${USER} ALL=(ALL) NOPASSWD: /usr/bin/pmset -a lowpowermode 0, /usr/bin/pmset -a lowpowermode 1"

# Check if rule already present
if sudo grep -Fxq "$RULE" /etc/sudoers; then
  echo "Sudoers rule already present."
  exit 0
fi

# Backup sudoers
sudo cp /etc/sudoers /etc/sudoers.bak

# Append rule safely using visudo
echo "$RULE" | sudo EDITOR='tee -a' visudo

# Validate sudoers syntax
if sudo visudo -c; then
  echo "Sudoers updated successfully."
else
  echo "Error in sudoers file! Restoring backup."
  sudo cp /etc/sudoers.bak /etc/sudoers
  exit 1
fi
