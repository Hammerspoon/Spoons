local obj = {
    name = "LowPowerToggle",
    version = "1.0",
    author = "Lox",
    homepage = "https://github.com/Loxed/low-power-toggle"
}

return obj

