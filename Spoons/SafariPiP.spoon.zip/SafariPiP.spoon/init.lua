--- === SafariPiP ===
---
--- Toggle Picture in Picture mode for videos playing in Safari.
---
--- This Spoon uses AppleScript to control Safari's PiP functionality via the
--- audio button in the toolbar. It works by clicking the audio/speaker icon
--- and selecting "Enter Picture in Picture" or "Exit Picture in Picture".
---
--- Requirements:
---  * macOS with Safari
---  * A video must be playing in Safari for PiP to work
---  * Hammerspoon must have Accessibility permissions
---
--- Download: https://github.com/Hammerspoon/Spoons
---
--- Example usage:
--- ```lua
--- hs.loadSpoon("SafariPiP"):bindHotkeys({
---     toggle = {{"ctrl", "alt"}, "P"}
--- })
--- ```

local obj = {}
obj.__index = obj

--- SafariPiP.name
--- Constant
--- The name of this Spoon
obj.name = "SafariPiP"

--- SafariPiP.version
--- Constant
--- The version of this Spoon
obj.version = "1.0"

--- SafariPiP.author
--- Constant
--- The author of this Spoon
obj.author = "alivault"

--- SafariPiP.homepage
--- Constant
--- The homepage for this Spoon
obj.homepage = "https://github.com/Hammerspoon/Spoons"

--- SafariPiP.license
--- Constant
--- The license for this Spoon
obj.license = "MIT - https://opensource.org/licenses/MIT"

--- SafariPiP.hotkey
--- Variable
--- The hotkey object created by bindHotkeys(), or nil if not bound
obj.hotkey = nil

local applescript = [[
    try
        if application "PIPAgent" is running then
            tell application "System Events"
                if exists (window 1 of process "PIPAgent") then
                    tell process "Safari"
                        set audioBtn to button 3 of group 3 of toolbar 1 of window 1
                        perform action "AXShowMenu" of audioBtn
                        delay 0.2
                        click menu item "Exit Picture in Picture" of menu 1 of group 3 of toolbar 1 of window 1
                    end tell
                    return
                end if
            end tell
        end if
        error "PiP not active"
    on error
        tell application "System Events"
            tell process "Safari"
                set audioBtn to button 3 of group 3 of toolbar 1 of window 1
                perform action "AXShowMenu" of audioBtn
                delay 0.2
                click menu item "Enter Picture in Picture" of menu 1 of group 3 of toolbar 1 of window 1
            end tell
        end tell
    end try
]]

--- SafariPiP:toggle()
--- Method
--- Toggle Picture in Picture mode in Safari
---
--- Parameters:
---  * None
---
--- Returns:
---  * None
---
--- Notes:
---  * A video must be playing in the frontmost Safari window
---  * If PiP is active, it will be closed
---  * If PiP is not active, it will be opened
function obj:toggle()
    hs.osascript.applescript(applescript)
end

--- SafariPiP:bindHotkeys(mapping)
--- Method
--- Bind hotkeys for SafariPiP
---
--- Parameters:
---  * mapping - A table containing hotkey mappings. The only supported key is:
---    * toggle - Toggle Picture in Picture on/off
---
--- Returns:
---  * The SafariPiP object
---
--- Example:
--- ```lua
--- spoon.SafariPiP:bindHotkeys({
---     toggle = {{"ctrl", "alt"}, "P"}
--- })
--- ```
function obj:bindHotkeys(mapping)
    local spec = {
        toggle = hs.fnutils.partial(self.toggle, self)
    }
    hs.spoons.bindHotkeysToSpec(spec, mapping)
    return self
end

return obj
